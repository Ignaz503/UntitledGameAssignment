﻿namespace UntitledGameAssignment.Core.Components
{
    public interface ILateUpdate : IActiveState
    {
        void LateUpdate();
    }
}
