﻿using UntitledGameAssignment.Core.GameObjects;
using Microsoft.Xna.Framework.Graphics;
using Util.SortingLayers;
using Util.Rendering;
using Microsoft.Xna.Framework;
using GeoUtil.Polygons;

namespace UntitledGameAssignment.Core.Components
{
    public class PolygonRenderer : SpriteRenderer
    {
        PolygonContainer container;

        Texture2D mask { get; set; }

        public PolygonRenderer(PolygonContainer container,SortingLayer layer, Texture2D sprite, Texture2D texture, Effect shader, GameObject obj ) : base(sprite,Color.White,layer,shader, obj )
        {
            this.mask = texture;
            this.container = container;
            container.OnPolygonChanged += OnPolygonChanged;
            OnPolygonChanged(container);//initial setup
        }

        public override void DoShaderSetup()
        {
            Shader.Parameters["Mask"].SetValue( mask );
        }

        public override void OnDestroy()
        {
            //dispose of effect?
            container.OnPolygonChanged -= OnPolygonChanged;
            container = null;
        }

        void OnPolygonChanged(PolygonContainer p) 
        {
            ThreadedDataRequestor.Instance.RequestData(()=> GenerateMask(container),OnMaskRecieved);
        }

        Texture2D GenerateMask( PolygonContainer p ) 
        {
            Texture2D newMask = new Texture2D(GameMain.Instance.GraphicsDevice,64,64);

            Color[] maskData = new Color[64*64];

            for (int i = 0; i < maskData.Length; i++)
            {
                int x = i % 64;
                int y = i / 64;

                Vector2 point = p.BoundsUVToPoint((float)x/(float)newMask.Width,(float)y/(float)newMask.Height);

                float val = GeoUtil.GeometryUtility.WindingNumberPointInPolygon(point,p.Polygon);
                float t = System.Math.Min(1f,System.Math.Abs( val ));
                maskData[i] = new Color(t,t,t,t);
            }

            newMask.SetData( maskData );
            return newMask;
        }

        void OnMaskRecieved( object obj ) 
        {
            mask = obj as Texture2D;
        }

    }
}
