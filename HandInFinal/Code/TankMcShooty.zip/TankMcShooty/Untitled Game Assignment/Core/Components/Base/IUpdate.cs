﻿namespace UntitledGameAssignment.Core.Components
{
    public interface IUpdate : IActiveState
    {
        void Update();
    }
}
