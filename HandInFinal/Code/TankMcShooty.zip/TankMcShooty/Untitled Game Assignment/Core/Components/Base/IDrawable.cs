﻿namespace UntitledGameAssignment.Core.Components
{

    public interface IDraw : IActiveState
    {
        void Draw();
    }
}
