﻿namespace UntitledGameAssignment.Core.Components
{
    public interface IFixedUpdate : IActiveState
    {
        void FixedUpdate();
    }
}
